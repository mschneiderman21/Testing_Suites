import requests
import binascii

api_key = 'NNSXS.OK22X5UNWI64GN3CIWOKCT7VZUEGN63BVKB4UDQ.SXLPBCEX3AVUUXK2WWBEVSLKZQ7XOSLV7HEYCFBSLREQRAL2LUKA'
base = 'https://tutorial123.nam1.cloud.thethings.industries/api/v3'

def downlink(frm_payload):  
  
  headers = {
  'Authorization': f'Bearer {api_key}',
  'Content-Type': 'application/json' 
  }

  data = {
    "downlinks":[{
      "frm_payload":frm_payload,
      "confirmed":False,
      "f_port":85}]
  }


  payload = requests.post(f'{base}/as/applications/temp-sensor/devices/wt201/down/push', json=data,  headers=headers)

  if payload.status_code == 200:
    print("Payload successfully delivered to the device")
  else:
    print(f"Error: {payload.status_code}")
    print("Please try again!")
    exit()


def toBase64(hex):
    binary = binascii.a2b_hex(hex)
    base64 = str(binascii.b2a_base64(binary))
    base64 = base64[2:len(base64)-3] 
    return base64


