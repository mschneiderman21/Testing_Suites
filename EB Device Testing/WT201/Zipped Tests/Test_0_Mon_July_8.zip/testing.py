import time
import tts_downlinks
import datetime

time_int = 280


def main():
    # Testing how long it takes the device to switch from stage 1 cooling to 
    # stage 2 cooling when the rate of cooling is 0 degrees/minute 

    # TESTING SETTINGS: Cooling rate of .1 C every 5 minutes till it dips below target at 21C
    ###       ^UTC-4             Enable ext (15 mins)  Fan auto      cool 70F ~ 21.1C  uplink int 5 mins    send temp of 22.8C ~ 73F
    test_0 = [("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb702c6", 50), ("ff8e000500", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e20000", time_int), ("03e10000", time_int), ("03e00000", time_int), ("03df0000", time_int), 
        ("03e00000", time_int), ("03df0000", time_int), ("03dd0000", time_int), ("03dc0000", time_int), ("03db0000", time_int),        
        ("03d90000", time_int), ("03d70000", time_int), ("03d60000", time_int), ("03d40000", time_int), ("03d50000", time_int),
        ("03d40000", time_int), ("03d30000", time_int), ("03d40000", time_int), ("03d30000", time_int), ("03d20000", time_int)]
    
    tot_num_downlinks = len(test_0)   
    num_downlinks_sent = 0 
    
    for tuple in test_0:
        time.sleep(tuple[1])
        frm_payload = tts_downlinks.toBase64(tuple[0])
        tts_downlinks.downlink(frm_payload)

        print(f"{num_downlinks_sent}/{tot_num_downlinks} sent...")
    
    print(f"The Program finished running at: {datetime.datetime.now}")
            
main()