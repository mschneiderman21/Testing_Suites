import time
import tts_downlinks
import datetime

time_int = 280

def main():

    # TESTING DESCRIPTION: Testing the wt201 smart thermostat cooling algorithm. Testing convergence to the target temperature. 
    # TESTING SETTINGS: Cooling rate of .1 C every 5 minutes till it dips below target at 21C
    #        Set interval to 1 min       ^UTC-4          Enable ext (15 mins)  Fan auto      Cool 70F ~ 21.1C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_0 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb702c6", 50), ("ff8e000500", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e20000", time_int), ("03e10000", time_int), ("03e00000", time_int), ("03df0000", time_int), 
        ("03e00000", time_int), ("03df0000", time_int), ("03dd0000", time_int), ("03dc0000", time_int), ("03db0000", time_int),        
        ("03d90000", time_int), ("03d70000", time_int), ("03d60000", time_int), ("03d40000", time_int), ("03d50000", time_int),
        ("03d40000", time_int), ("03d30000", time_int), ("03d40000", time_int), ("03d30000", time_int), ("03d20000", time_int)]

    # TESTING DESCRIPTION: Testing the wt201 smart thermostat cooling algorithm. Testing divergence to the target temperature. 
    # TESTING SETTINGS: Cooling rate of about -.1 C every 5 minutes till it reaches 24C
    #         Set interval to 1min      ^UTC-4          Enable ext (15 mins)  Fan auto      Cool 70F ~ 21.1C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_1 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb702c6", 50), ("ff8e00100", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e40000", time_int), ("03e50000", time_int), 
        ("03e60000", time_int), ("03e70000", time_int), ("03e60000", time_int), ("03e70000", time_int), ("03e80000", time_int),        
        ("03e90000", time_int), ("03ea0000", time_int), ("03e80000", time_int), ("03ea0000", time_int), ("03ec0000", time_int),
        ("03ee0000", time_int), ("03ef0000", time_int), ("03f00000", time_int), ("03ef0000", time_int), ("03f00000", time_int)]

    # TESTING DESCRIPTION: Testing the wt201 smart thermostat cooling algorithm. Testing flatlining to the target temperature. 
    # TESTING SETTINGS: The target temp is 21.1 however it will stay at 22.8C and will fluctuate by +-.3C
    #         Set interval to 1min      ^UTC-4          Enable ext (15 mins)  Fan auto      Cool 70F ~ 21.1C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_2 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb702c6", 50), ("ff8e000100", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e20000", time_int), ("03e10000", time_int), ("03e10000", time_int), ("03e20000", time_int), 
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e40000", time_int), ("03e20000", time_int),        
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e60000", time_int), ("03e50000", time_int),
        ("03e40000", time_int), ("03e30000", time_int), ("03e20000", time_int), ("03e30000", time_int), ("03e40000", time_int)]


    # TESTING DESCRIPTION: Testing the wt201 smart thermostat heating algorithm. Testing comvergence to the target temperature. 
    # TESTING SETTINGS: Heating rate of about .1 C every 5 minutes till it reaches 23.3C
    #         Set interval to 1min      ^UTC-4          Enable ext (15 mins)  Fan auto      Heat 75F ~ 23.9C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_3 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb700cb", 50), ("ff8e000100", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e40000", time_int), ("03e50000", time_int), 
        ("03e60000", time_int), ("03e70000", time_int), ("03e60000", time_int), ("03e70000", time_int), ("03e80000", time_int),        
        ("03e90000", time_int), ("03ea0000", time_int), ("03e80000", time_int), ("03ea0000", time_int), ("03ec0000", time_int),
        ("03ee0000", time_int), ("03ef0000", time_int), ("03f00000", time_int), ("03ef0000", time_int), ("03f00000", time_int)]

    # TESTING DESCRIPTION: Testing the wt201 smart thermostat heating algorithm. Testing divergence to the target temperature. 
    # TESTING SETTINGS: Heating rate of about -.1 C every 5 minutes till it dips below target at 21C
    #          Set interval to 1 min      ^UTC-4          Enable ext (15 mins)  Fan auto      Heat 75F ~ 23.9C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_4 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb700cb", 50), ("ff8e000100", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e20000", time_int), ("03e10000", time_int), ("03e00000", time_int), ("03df0000", time_int), 
        ("03e00000", time_int), ("03df0000", time_int), ("03dd0000", time_int), ("03dc0000", time_int), ("03db0000", time_int),        
        ("03d90000", time_int), ("03d70000", time_int), ("03d60000", time_int), ("03d40000", time_int), ("03d50000", time_int),
        ("03d40000", time_int), ("03d30000", time_int), ("03d40000", time_int), ("03d30000", time_int), ("03d20000", time_int)]

    # TESTING DESCRIPTION: Testing the wt201 smart thermostat heating algorithm. Testing divergence to the target temperature. 
    # TESTING SETTINGS: Heating rate of about -.1 C every 5 minutes till it dips below target at 21C
    #          Set interval to 1 min      ^UTC-4          Enable ext (15 mins)  Fan auto      Heat 75F ~ 23.9C   Uplink int 5 mins    Send temp of 22.8C ~ 73F
    test_5 = [("ff8e000100", time_int), ("ffbd10ff", 50), ("ffc4010f", 50), ("ffb600", 50),  ("ffb700cb", 50), ("ff8e000100", 50), ("03e40000", time_int), 
        ("03e30000", time_int), ("03e20000", time_int), ("03e10000", time_int), ("03e10000", time_int), ("03e20000", time_int), 
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e40000", time_int), ("03e20000", time_int),        
        ("03e30000", time_int), ("03e40000", time_int), ("03e50000", time_int), ("03e60000", time_int), ("03e50000", time_int),
        ("03e40000", time_int), ("03e30000", time_int), ("03e20000", time_int), ("03e30000", time_int), ("03e40000", time_int)]
    
    tests = [test_0, test_1, test_2, test_3, test_4, test_5]
    
    test_num = 0


    # Wait untill 8 PM to start testing
    wait_until()

    print(f"The testing began at {datetime.datetime.now()}")
    for test in tests:
        tot_num_downlinks = len(test)   
        num_downlinks_sent = 0 
        print(f"Started running test #{test_num} at: {datetime.datetime.now()}")
        for tuple in test:
            time.sleep(tuple[1])
            frm_payload = tts_downlinks.toBase64(tuple[0])
            tts_downlinks.downlink(frm_payload)

            print(f"{num_downlinks_sent}/{tot_num_downlinks} sent...")
            num_downlinks_sent += 1
        print(f"Finished running test #{test_num} at: {datetime.datetime.now()}")
        test_num += 1

        # 5 Minute Delay Between Tests
        time.sleep(300)

    print(f"The Program finished running at: {datetime.datetime.now()}")


def wait_until():
    now = datetime.datetime.now()
    next = (now + datetime.timedelta(days=1)).replace(hour=19, minute=0, second=0, microsecond=0)
    time_to_midnight = (next - now).total_seconds()
    print(f"Waiting for {time_to_midnight} seconds until midnight.")
    time.sleep(time_to_midnight + 120)
    print("It's 8PM! Starting the program...")    
            
if __name__ == "__main__":
    main()
